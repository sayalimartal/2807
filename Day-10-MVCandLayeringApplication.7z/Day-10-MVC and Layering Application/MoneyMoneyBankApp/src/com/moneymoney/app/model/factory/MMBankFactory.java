package com.moneymoney.app.model.factory;

import java.util.Map;

import com.moneymoney.framework.factory.BankFactory;

public class MMBankFactory extends BankFactory {

	@Override
	public void createNewCurrentAccount(Map<String, Object> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createNewSavingsAccount(Map<String, Object> arg0) {
		// TODO Auto-generated method stub
		
	}
}
