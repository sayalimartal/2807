package com.moneymoney.app.console.controller;

import java.util.Collection;
import java.util.Map;

import com.moneymoney.framework.account.pojo.BankAccount;
import com.moneymoney.framework.account.pojo.Customer;
import com.moneymoney.framework.controller.BankController;

public class MMBankAccountController extends BankController {

	@Override
	public void createNewCurrentAccount(Map<String, Object> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createNewSavingsAccount(Map<String, Object> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Collection<BankAccount> getAllAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

}
